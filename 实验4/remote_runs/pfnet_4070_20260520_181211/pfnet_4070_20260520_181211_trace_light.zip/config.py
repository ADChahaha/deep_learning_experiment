﻿"""
 @Time    : 2021/7/6 09:46
 @Author  : Haiyang Mei
 @E-mail  : mhy666@mail.dlut.edu.cn

 @Project : CVPR2021_PFNet
 @File    : config.py
 @Function: Configuration

"""
import os

backbone_path = './backbone/resnet/resnet50-19c8e357.pth'

datasets_root = './dataset_raw'

cod_training_root = os.path.join(datasets_root, 'TrainDataset')

chameleon_path = os.path.join(datasets_root, 'TestDataset/CHAMELEON')
camo_path = os.path.join(datasets_root, 'TestDataset/CAMO')
cod10k_path = os.path.join(datasets_root, 'TestDataset/COD10K')
nc4k_path = os.path.join(datasets_root, 'TestDataset/NC4K')
